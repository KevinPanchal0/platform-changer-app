class ThemeModel {
  late bool isDark;

  ThemeModel({required this.isDark});
}
