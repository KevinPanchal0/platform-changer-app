class InterfaceChangeModel{
  late bool isAndroid;

  InterfaceChangeModel({required this.isAndroid});
}