class ContactModel {
  String image;
  String name;
  String phone;

  ContactModel({required this.name, required this.phone, required this.image});
}
