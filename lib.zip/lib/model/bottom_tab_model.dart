class BottomTabModel{
  int currentIndex = 0;

}