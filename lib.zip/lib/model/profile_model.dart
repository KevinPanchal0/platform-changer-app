class ProfileModel {
  String name;
  String phone;
  String email;
  String dob;
  String gender;
  ProfileModel(
      {required this.name,
      required this.phone,
      required this.email,
      required this.dob,
      required this.gender,});
}
