import 'package:flutter/material.dart';
import 'package:platform_changer_app/model/contact_model.dart';

class ContactProvider with ChangeNotifier {
  List<ContactModel> _contactList = [];

  List<ContactModel> get contactList => _contactList;

  void addContact(ContactModel data) {
    _contactList.add(data);
    notifyListeners();
  }

  Future<void> removeContact({required ContactModel data}) async {
    _contactList.remove(data);
    notifyListeners();
  }

  Future<void> updateContact(ContactModel updatedContact) async {
    int index = _contactList.indexOf(updatedContact);
    if (index != -1) {
      _contactList[index] = updatedContact;
      notifyListeners();
    }
    notifyListeners();
  }
}
