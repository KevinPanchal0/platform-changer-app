import 'package:flutter/material.dart';
import 'package:platform_changer_app/model/profile_model.dart';

class ProfileProvider with ChangeNotifier {
  ProfileModel _profileModel = ProfileModel(
      name: '',
      phone: '',
      email: '',
      dob: '',
      gender: '',);

  ProfileModel get profileModel => _profileModel;

  void updateProfile(String name, String email, String phone,
      String dob, String gender) {
    _profileModel = ProfileModel(
      name: name,
      email: email,
      phone: phone,
      dob: dob,
      gender: gender,
    );
    notifyListeners();
  }
}
