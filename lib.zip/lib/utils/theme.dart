import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ThemeToggle{
  final ThemeData lightTheme = ThemeData.light();
  final ThemeData darkTheme = ThemeData.dark();
  final CupertinoThemeData lightThemeCupertino =const CupertinoThemeData(
    applyThemeToAll: true,
      textTheme: CupertinoTextThemeData(
          textStyle: TextStyle(
            color: CupertinoColors.black,
          )
      ),
    brightness: Brightness.light
  );
  final CupertinoThemeData darkThemeCupertino =const CupertinoThemeData(
    applyThemeToAll: true,
    textTheme: CupertinoTextThemeData(
    ),
    brightness: Brightness.dark
  );

  }