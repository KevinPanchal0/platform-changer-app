import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../model/contact_model.dart';
import '../providers/contact_provider.dart';
import '../providers/interface_change_provider.dart';

class DetailPage extends StatefulWidget {
  const DetailPage({super.key});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    ContactModel contact =
        ModalRoute.of(context)!.settings.arguments as ContactModel;
    final contacts = Provider.of<ContactProvider>(context, listen: false);

    nameController.text = contact.name;
    phoneController.text = contact.phone;
    return (Provider.of<InterfaceChangeProvider>(context)
        .interfaceChangeModel
        .isAndroid)
        ? CupertinoPageScaffold(
      child: Column(
        children: [],
      ),
    )
        : Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Card(
              elevation: 5,
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height / 2,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                fit: BoxFit.fill,
                                image: FileImage(File(contact.image))),
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(60),
                                topRight: Radius.circular(60))),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(
                                Icons.chevron_left,
                                color: Colors.orangeAccent,
                                size: 40,
                              )),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Text(
                    contact.name,
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    contact.phone,
                    style: TextStyle(
                      fontSize: 26,
                    ),
                  ),
                  const SizedBox(
                    height: 36,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          IconButton(
                            style: ButtonStyle(
                                backgroundColor: WidgetStateProperty.all(
                                    Colors.orangeAccent)),
                            onPressed: () async {
                              await launchUrl(
                                  Uri.parse('tel:' '+91${contact.phone}'));
                            },
                            icon: const Icon(
                              Icons.call,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Call',
                            style: TextStyle(fontSize: 20),
                          )
                        ],
                      ),
                      Column(
                        children: [
                          IconButton(
                            style: ButtonStyle(
                                backgroundColor: WidgetStateProperty.all(
                                    Colors.orangeAccent)),
                            onPressed: () async {
                              await launchUrl(
                                  Uri.parse('sms:' '+91 ${contact.phone}'));
                            },
                            icon: const Icon(
                              Icons.messenger,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Massage',
                            style: TextStyle(fontSize: 20),
                          )
                        ],
                      ),
                      Column(
                        children: [
                          IconButton(
                              onPressed: () {
                                showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: Text('Are you sure?'),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.pop(context);
                                              // contacts.removeContact(data: contact);
                                            },
                                            child: Text('Cancle'),
                                          ),
                                          TextButton(
                                            onPressed: () async {
                                              await contacts.removeContact(
                                                  data: contact);
                                              Navigator.pop(context);
                                              Navigator.pop(context);
                                            },
                                            child: Text('Delete'),
                                          ),
                                        ],
                                      );
                                    });
                              },
                              style: ButtonStyle(
                                  backgroundColor: WidgetStateProperty.all(
                                      Colors.orangeAccent)),
                              icon: Icon(
                                Icons.delete,
                                color: Colors.white,
                                size: 30,
                              )),
                          Text(
                            'Delete',
                            style: TextStyle(fontSize: 20),
                          )
                        ],
                      )
                    ],
                  ),
                  SizedBox(
                    height: 25,
                  ),
                ],
              ),
            ),
            Column(
              children: [
                IconButton(
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: Text('Edit Contact'),
                            actions: [
                              Center(
                                child: CircleAvatar(
                                  radius: 36,
                                  backgroundImage: FileImage(File(contact.image)),
                                ),
                              ),
                              TextField(
                                controller: nameController,
                              ),
                              TextField(
                                controller: phoneController,
                                maxLength: 10,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  TextButton(
                                      onPressed: () {
                                        contact.name = nameController.text;
                                        contact.phone = phoneController.text;
                                        contacts.updateContact(ContactModel(
                                            name: nameController.text,
                                            phone: phoneController.text,
                                            image: contact.image));
                                        Navigator.pop(context);
                                      },
                                      child: Text('Update')),
                                  TextButton(
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                      child: Text('Cancel')),
                                ],
                              ),
                            ],
                          );
                        });
                  },
                  style: ButtonStyle(
                      backgroundColor:
                          WidgetStateProperty.all(Colors.orangeAccent)),
                  icon: const Icon(
                    Icons.edit,
                    color: Colors.white,
                  ),
                ),
                const Text('Edit')
              ],
            )
          ],
        ),
      ),
    );
  }
}
